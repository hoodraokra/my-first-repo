package userinterface;

import gamelogic.TicTacToeGame;
import gamelogic.GameListener;
import gamelogic.Opponent;

public class SwingUI implements TicTacToeUI {
    public void start(TicTacToeGame game, boolean vsAI, Opponent ai, TicTacToeGame.Mark aiPlaysAs) {
        System.out.println("Swing UI not implemented. Placeholder.");
    }
}
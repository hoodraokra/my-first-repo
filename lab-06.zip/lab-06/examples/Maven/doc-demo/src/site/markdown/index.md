# Documentation Demo

This site is generated with `mvn site`. It includes:

- Javadoc
- Test report (Surefire)
- Code coverage (JaCoCo)
- Project information pages (dependencies, plugins, etc.)


public class Food {
    private String type;

    public Food(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
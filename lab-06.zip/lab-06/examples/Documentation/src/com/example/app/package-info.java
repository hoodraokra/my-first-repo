/**
 * Application entry points and demos.
 *
 * @since 1.0
 */
package com.example.app;

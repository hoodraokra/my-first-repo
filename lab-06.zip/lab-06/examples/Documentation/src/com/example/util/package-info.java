/**
 * General-purpose helper utilities.
 *
 * <p>Only a single utility is included to keep the example focused.</p>
 *
 * @since 1.0
 */
package com.example.util;

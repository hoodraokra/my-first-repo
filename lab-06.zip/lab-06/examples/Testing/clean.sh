#!/bin/bash

find ./out/ -type f -iname '*.class' -delete

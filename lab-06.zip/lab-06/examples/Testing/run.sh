#!/bin/bash

java -cp out/myprog:out/main com.myprog.main.Main

package com.example.math;

public class BooleanLogic {

    public static boolean And(boolean a, boolean b) {
        return a && b;
    }

    public static boolean Or(boolean a, boolean b) {
        return a || b;
    }

    public static boolean Not(boolean a) {
        return !a;
    }

    public static boolean Xor(boolean a, boolean b) {
        return a ^ b;
    }
}